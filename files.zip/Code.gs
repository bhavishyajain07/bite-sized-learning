/**
 * INDIAN INTERNET FEATURE TRACKER — AUTOMATION
 * --------------------------------------------
 * Runs weekly, pulls news from Google News RSS for each company,
 * filters to last 7 days, deduplicates, appends to your tracker sheet,
 * and emails you a digest.
 *
 * SETUP (one-time, 5 minutes):
 *   1. Open your Google Sheet (the one you uploaded from the .xlsx).
 *   2. Extensions → Apps Script. Paste this entire file. Save.
 *   3. Edit the CONFIG section below (your email, etc).
 *   4. Run the function "setupTrigger" once. Approve permissions when prompted.
 *   5. Done. It now runs every Monday 8 AM IST automatically.
 *
 * To test immediately: run "runWeeklyFetch" manually from the Apps Script editor.
 */

// ============ CONFIG — EDIT THESE ============
const CONFIG = {
  EMAIL_TO: "your-email@example.com",          // <-- CHANGE THIS to your email
  SHEET_NAME: "Feature Tracker",                // Name of the tab to write to
  LOOKBACK_DAYS: 7,                             // Only include news from last N days
  MAX_PER_COMPANY: 3,                           // Max new entries per company per run
  RUN_DAY: ScriptApp.WeekDay.MONDAY,            // Day of week to run
  RUN_HOUR: 8,                                  // Hour (24h, IST since Sheet timezone)
};

// Companies to track. Add/remove freely.
// Use search terms that are distinctive — bare "Ola" pulls noise, "Ola Cabs" doesn't.
const COMPANIES = [
  { name: "Swiggy",       category: "Food / Q-commerce", query: "Swiggy" },
  { name: "Zomato",       category: "Food",              query: "Zomato" },
  { name: "Blinkit",      category: "Q-commerce",        query: "Blinkit" },
  { name: "Zepto",        category: "Q-commerce",        query: "Zepto" },
  { name: "Flipkart",     category: "E-commerce",        query: "Flipkart" },
  { name: "Myntra",       category: "Fashion",           query: "Myntra" },
  { name: "Meesho",       category: "E-commerce",        query: "Meesho" },
  { name: "Nykaa",        category: "Beauty",            query: "Nykaa" },
  { name: "PhonePe",      category: "Fintech",           query: "PhonePe" },
  { name: "Paytm",        category: "Fintech",           query: "Paytm" },
  { name: "CRED",         category: "Fintech",           query: "CRED app" },
  { name: "Razorpay",     category: "Fintech / B2B",     query: "Razorpay" },
  { name: "Groww",        category: "Fintech / Invest",  query: "Groww app" },
  { name: "Zerodha",      category: "Fintech / Invest",  query: "Zerodha" },
  { name: "MakeMyTrip",   category: "Travel",            query: "MakeMyTrip" },
  { name: "Ola",          category: "Mobility",          query: "Ola Cabs" },
  { name: "Uber India",   category: "Mobility",          query: "Uber India" },
  { name: "Rapido",       category: "Mobility",          query: "Rapido bike" },
  { name: "BookMyShow",   category: "Entertainment",     query: "BookMyShow" },
  { name: "Hotstar",      category: "Streaming",         query: "JioHotstar" },
  { name: "Dream11",      category: "Gaming",            query: "Dream11" },
  { name: "Urban Company", category: "Services",         query: "Urban Company" },
  { name: "PolicyBazaar", category: "Insurance",         query: "PolicyBazaar" },
];

// Keywords that signal a feature launch (not just any company news).
// A headline must match at least one to be included.
const LAUNCH_KEYWORDS = [
  "launch", "launches", "launched", "rolls out", "rolled out", "rolling out",
  "introduces", "introduced", "unveils", "unveiled", "announces", "announced",
  "debuts", "now available", "goes live", "new feature", "new product",
  "beta", "rolling", "expands to", "now offers", "pilot",
];

// ============ MAIN ENTRY POINTS ============

/**
 * Run this ONCE from the Apps Script editor to install the weekly trigger.
 */
function setupTrigger() {
  // Clear any existing triggers for this function
  ScriptApp.getProjectTriggers().forEach(t => {
    if (t.getHandlerFunction() === "runWeeklyFetch") {
      ScriptApp.deleteTrigger(t);
    }
  });

  ScriptApp.newTrigger("runWeeklyFetch")
    .timeBased()
    .onWeekDay(CONFIG.RUN_DAY)
    .atHour(CONFIG.RUN_HOUR)
    .create();

  Logger.log("✅ Trigger installed. Runs every " +
    CONFIG.RUN_DAY.toString() + " at " + CONFIG.RUN_HOUR + ":00.");

  // Run once immediately so the user sees output right away
  runWeeklyFetch();
}

/**
 * The main weekly job. Triggered automatically; can also be run manually for testing.
 */
function runWeeklyFetch() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(CONFIG.SHEET_NAME);
  if (!sheet) {
    throw new Error("Could not find sheet named: " + CONFIG.SHEET_NAME);
  }

  const existingLinks = getExistingLinks(sheet);
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - CONFIG.LOOKBACK_DAYS);

  const newEntries = [];

  for (const company of COMPANIES) {
    try {
      const items = fetchGoogleNews(company.query);
      let added = 0;

      for (const item of items) {
        if (added >= CONFIG.MAX_PER_COMPANY) break;
        if (item.pubDate < cutoffDate) continue;
        if (existingLinks.has(item.link)) continue;
        if (!looksLikeLaunch(item.title)) continue;

        newEntries.push({
          date: formatDate(item.pubDate),
          company: company.name,
          category: company.category,
          featureName: item.title,
          description: item.title,             // Headline = description for now; you can refine
          type: "Auto-fetched",
          status: "Reported",
          targetUsers: "",
          sourceType: "News",
          sourceUrl: item.link,
          notes: "Auto-added on " + formatDate(new Date()),
        });
        existingLinks.add(item.link);
        added++;
      }

      Utilities.sleep(500); // Be nice to Google News
    } catch (err) {
      Logger.log("Error for " + company.name + ": " + err);
    }
  }

  if (newEntries.length === 0) {
    Logger.log("No new entries this run.");
    sendEmail([], "No new launches found this week.");
    return;
  }

  appendToSheet(sheet, newEntries);
  sendEmail(newEntries);
  Logger.log("✅ Added " + newEntries.length + " new entries.");
}

// ============ HELPERS ============

function fetchGoogleNews(query) {
  // Google News RSS — no API key needed
  const url = "https://news.google.com/rss/search?q=" +
    encodeURIComponent(query) +
    "&hl=en-IN&gl=IN&ceid=IN:en";

  const response = UrlFetchApp.fetch(url, { muteHttpExceptions: true });
  const xml = response.getContentText();
  const doc = XmlService.parse(xml);
  const channel = doc.getRootElement().getChild("channel");
  const items = channel.getChildren("item");

  return items.map(item => ({
    title: item.getChildText("title") || "",
    link: cleanGoogleLink(item.getChildText("link") || ""),
    pubDate: new Date(item.getChildText("pubDate")),
    source: item.getChild("source") ? item.getChild("source").getText() : "",
  }));
}

function cleanGoogleLink(googleUrl) {
  // Google News wraps the real URL. We keep the Google URL because it redirects
  // correctly — but we could unwrap if desired.
  return googleUrl;
}

function looksLikeLaunch(title) {
  const lower = title.toLowerCase();
  return LAUNCH_KEYWORDS.some(kw => lower.includes(kw));
}

function getExistingLinks(sheet) {
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return new Set();
  // Column J (10) = Source URL. Adjust if your column order differs.
  const range = sheet.getRange(2, 10, lastRow - 1, 1).getValues();
  return new Set(range.map(r => r[0]).filter(Boolean));
}

function appendToSheet(sheet, entries) {
  const rows = entries.map(e => [
    e.date, e.company, e.category, e.featureName, e.description,
    e.type, e.status, e.targetUsers, e.sourceType, e.sourceUrl, e.notes
  ]);
  sheet.getRange(sheet.getLastRow() + 1, 1, rows.length, rows[0].length)
       .setValues(rows);
}

function formatDate(d) {
  return Utilities.formatDate(d, "Asia/Kolkata", "yyyy-MM-dd");
}

function sendEmail(newEntries, overrideMessage) {
  const subject = newEntries.length > 0
    ? `🚀 ${newEntries.length} new feature launches this week`
    : "Weekly tracker run — no new launches";

  let body = `<h2>Indian Internet — Weekly Feature Launches</h2>`;
  body += `<p>Run date: ${formatDate(new Date())}</p>`;

  if (overrideMessage) {
    body += `<p>${overrideMessage}</p>`;
  } else {
    body += `<table border="1" cellpadding="8" cellspacing="0" style="border-collapse:collapse;font-family:Arial,sans-serif;font-size:13px;">`;
    body += `<tr style="background:#1F4E78;color:white;"><th>Date</th><th>Company</th><th>Headline</th><th>Link</th></tr>`;
    for (const e of newEntries) {
      body += `<tr>
        <td>${e.date}</td>
        <td><b>${e.company}</b></td>
        <td>${escapeHtml(e.featureName)}</td>
        <td><a href="${e.sourceUrl}">Read</a></td>
      </tr>`;
    }
    body += `</table>`;
    body += `<p style="margin-top:20px;">View the full tracker: <a href="${SpreadsheetApp.getActiveSpreadsheet().getUrl()}">Open Sheet</a></p>`;
  }

  MailApp.sendEmail({
    to: CONFIG.EMAIL_TO,
    subject: subject,
    htmlBody: body,
  });
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
